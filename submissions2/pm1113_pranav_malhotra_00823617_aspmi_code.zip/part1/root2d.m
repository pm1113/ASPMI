function F = root2d(x)
N=100;
F(1) = 1/sqrt(2);
F(2) = 1/N.*(sin(2*pi*f*N)./sin(2*pi*f)).^2;
end
