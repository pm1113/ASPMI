function graph_saving(filename)
print(filename,'-depsc')
end